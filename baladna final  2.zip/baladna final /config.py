import os 

# config.py
ADMIN_USERNAME = 'baladna'
ADMIN_PASSWORD = '5500'

